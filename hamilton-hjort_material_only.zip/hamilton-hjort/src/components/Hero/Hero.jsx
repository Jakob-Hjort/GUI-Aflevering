import { Link } from "react-router-dom";
import "./Hero.css";

// Hero er en genbrugelig "top-sektion" til en side.
// Vi bruger props til at gøre den fleksibel.
export default function Hero({ title, subtitle }) {
  return (
    <section className="hero">
      <div className="container heroInner">
        <div className="heroText">
          <h1 className="heroTitle">{title}</h1>
          <p className="heroSubtitle">{subtitle}</p>

          <div className="heroActions">
            <Link className="heroBtn" to="/products">
              Se alle produkter
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

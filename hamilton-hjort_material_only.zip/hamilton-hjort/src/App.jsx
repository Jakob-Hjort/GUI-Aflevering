import { Routes, Route } from "react-router-dom";
import MainLayout from "./components/MainLayout/MainLayout";

// Pages (Routes)
import Home from "./pages/Home";
import Products from "./pages/Products/Products";
import ProductDetails from "./pages/ProductDetails/ProductDetails";

export default function App() {
  return (
    // MainLayout er vores "skal" (Header + Navigation + Footer).
    // Alt indholdet på siderne bliver sat ind her som children.
    <MainLayout>
      <Routes>
        {/* Standard-side */}
        <Route path="/" element={<Home />} />

        {/* Products: enten alle produkter, eller produkter i en kategori */}
        <Route path="/products" element={<Products />} />
        <Route path="/products/category/:categoryId" element={<Products />} />

        {/* Single product: dynamisk side baseret på :id */}
        <Route path="/products/:id" element={<ProductDetails />} />
      </Routes>
    </MainLayout>
  );
}
